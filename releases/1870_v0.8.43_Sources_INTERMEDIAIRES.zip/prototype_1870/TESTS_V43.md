# Tests V43 — état intermédiaire

Godot 4.5.1 réellement utilisé. Contrôles ciblés réussis : Raoult 40/40 ; cavalerie 4096/4096 ; variante B 1660/1660 ; interface V43 26/26 ; rendu réel du projectile sous Linux X11/OpenGL llvmpipe 53/53. Cinq captures sur dix terrains et quatre zooms (0,42 / 0,72 / 1 / 2,3) sont conservées dans tests/results/0843. Il ne s’agit pas d’un téléphone Android.

La première passe de 22 suites historiques a rencontré un test de redémarrage obsolète : il attendait l’ancien prototype. Son attente a été adaptée au remplacement explicite par V43, en vérifiant également la conservation de la sauvegarde historique. Le test adapté passe 27/27 ; les autres assertions du test restent intactes.

Les rapports définitifs des régressions et de l’export Android seront consolidés dans la livraison finale. Aucun test de bataille complète V43 ni essai physique Android n’est déclaré à ce stade. Cette archive intermédiaire fournit déjà le projet complet et les corrections ciblées testées.
