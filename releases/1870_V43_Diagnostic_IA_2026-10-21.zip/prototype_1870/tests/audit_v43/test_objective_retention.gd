extends "res://tests/test_ai_compat0833.gd"
const Original=preload("res://tests/audit_v43/original_ai.gd")
func _initialize():
 profiles=JSON.parse_string(FileAccess.get_file_as_string("res://packs/1870/ai_profiles.json"))
 var directory=OS.get_cmdline_user_args()[0];var report=JSON.parse_string(FileAccess.get_file_as_string(directory.path_join("full_battle_report.json")));var trace=JSON.parse_string(FileAccess.get_file_as_string(directory.path_join("trace_T06_A0372.json")))
 var p=JSON.parse_string(FileAccess.get_file_as_string("res://packs/1870/regimental_trial_v43.json"));var e=Rules.new(p);e.state=trace.state;e.normalize();var result={};var id="v42_de_reserve_04";var n=e.unit_index(id)
 for k in range(372,report.actions.size()):
  var a=report.actions[k];var d=a.decision
  if int(a.turn)>9:break
  if int(a.turn)==8 and str(d.get("unit",""))==id and d.kind=="move" and int(d.path[0])==161:
   result.state_before_departure=e.state.duplicate(true)
   result.before_departure=e.state.units[n].duplicate(true);result.owner_before=e.state.objective_owners.froeschwiller
   var ai=bot();var baseline=Original.new();baseline.profiles=profiles;var view=e.observation(1)
   result.chosen=ai.choose(view);result.trace=ai.diagnostics.get(id,{})
   check(JSON.parse_string(JSON.stringify(result.chosen))==d and JSON.parse_string(JSON.stringify(baseline.choose(view)))==d,"actual objective departure reproduced by unchanged AI")
  check(dispatch(e,d),"legal replay for retention case")
  if int(a.turn)==8 and str(d.get("unit",""))==id and d.kind=="assault":result.after_capture=e.state.units[n].duplicate(true);result.capture_event=e.state.events[-1].duplicate(true)
  if result.has("before_departure") and int(a.turn)==8 and str(d.get("unit",""))==id and d.kind=="move":result.after_departure=e.state.units[n].duplicate(true)
  if result.has("after_departure") and int(a.turn)==9 and int(a.side)==0 and int(e.state.objective_owners.froeschwiller)==0:
   result.recapture_command=d;result.recapture_turn=9;break
 check(result.has("capture_event") and result.has("after_departure") and result.has("recapture_command"),"capture, voluntary withdrawal and French recapture observed")
 result.checks=checks;result.failures=failures
 var f=FileAccess.open("user://objective_retention.json",FileAccess.WRITE);f.store_string(JSON.stringify(result,"\t"));f.close()
 print("OBJECTIVE RETENTION AUDIT ",checks-failures,"/",checks);quit(1 if failures else 0)
