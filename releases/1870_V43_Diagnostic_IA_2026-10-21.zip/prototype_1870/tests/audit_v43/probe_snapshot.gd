extends "res://tests/test_ai_compat0833.gd"
const Original=preload("res://tests/audit_v43/original_ai.gd")
func _initialize():
 profiles=JSON.parse_string(FileAccess.get_file_as_string("res://packs/1870/ai_profiles.json"))
 var trace=JSON.parse_string(FileAccess.get_file_as_string(OS.get_cmdline_user_args()[0]));var p=JSON.parse_string(FileAccess.get_file_as_string("res://packs/1870/regimental_trial_v43.json"));var e=Rules.new(p);e.state=trace.state;e.normalize();var view=e.observation(1);var ai=bot();var baseline=Original.new();baseline.profiles=profiles
 var decision=ai.choose(view);check(decision==baseline.choose(view),"enriched artillery diagnostics preserve original choice")
 var f=FileAccess.open("user://snapshot_probe.json",FileAccess.WRITE);f.store_string(JSON.stringify({"checks":checks,"failures":failures,"units":ai.diagnostics,"decision":decision},"\t"));f.close();print("SNAPSHOT PROBE ",checks-failures,"/",checks);quit(1 if failures else 0)
