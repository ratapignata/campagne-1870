extends "res://tests/v36/test_ai_active.gd"
const Original=preload("res://tests/audit_v43/original_ai.gd")
var result={"phases":[],"units":[],"parity":[],"checks":0,"failures":0}
func existing_report():return JSON.parse_string(FileAccess.get_file_as_string(OS.get_cmdline_user_args()[0]))
func snapshots(e):
 var rows={}
 for n in range(e.state.units.size()):
  var u=e.state.units[n]
  if int(u.side)==1 and e.alive(n):rows[str(u.id)]={"initial":u.duplicate(true),"actions":[],"ap_spent":0,"crossings":0}
 return rows
func legal_info(e,n):
 var u=e.state.units[n];var reach=e.reach(n);var free=0;var occupied=[];var legal_fire=[];var legal_assault=[];var batteries=[]
 for dest in reach.costs:
  if dest==e.unit_cell(u):continue
  var occupant=e.unit_at(dest)
  if occupant<0:free+=1
  elif int(e.state.units[occupant].side)==1:occupied.append(e.state.units[occupant].id)
 for j in range(e.state.units.size()):
  if e.fire_status(n,j)=="ok":legal_fire.append(e.state.units[j].id)
  if e.assault_status(n,j)=="ok":legal_assault.append(e.state.units[j].id)
 for a in range(e.state.units.size()):
  if not e.can_act(a) or not e.artillery(a):continue
  for j in range(e.state.units.size()):
   if int(e.state.units[j].side)==0 and e.alive(j) and e.distance(e.unit_cell(u),e.unit_cell(e.state.units[j]))<=3 and e.fire_status(a,j)=="ok":batteries.append(e.state.units[a].id);break
 return {"can_act":e.can_act(n),"reachable_empty":free,"occupied_endpoints":occupied,"legal_fire":legal_fire,"legal_assault":legal_assault,"available_support_batteries":batteries}
func finish_phase(e,turn,rows,counts,elapsed,crossings,loss_start):
 var phase={"turn":turn,"counts":counts,"moved_units":0,"inactive_units":0,"stationary_units":0,"unused_ap":0,"legally_mobile_at_end":0,"legally_attackable_at_end":0,"crossings":crossings,"prussian_decision_ms":elapsed,"losses_at_end":[e.losses(0),e.losses(1)],"losses_during_prussian_phase":[e.losses(0)-loss_start[0],e.losses(1)-loss_start[1]],"objectives":e.state.objective_owners.duplicate(),"prussian_pending":0,"command_cut":0,"supply_cut":0,"double_cut":0,"bridge_occupants":[]}
 for u in e.state.units:
  if int(u.side)==1 and u.get("pending",false):phase.prussian_pending+=1
 for cell in [343,344,382,412]:
  var n=e.unit_at(cell)
  if n>=0:phase.bridge_occupants.append({"cell":[e.cell(cell).x,e.cell(cell).y],"unit":e.state.units[n].id,"side":e.state.units[n].side})
 for id in rows:
  var row=rows[id];var n=e.unit_index(id);var u=e.state.units[n];var moved=u.cell!=row.initial.cell;var ever_moved=false
  for command in row.actions:
   if command.kind=="move":ever_moved=true
  if ever_moved:phase.moved_units+=1
  if not moved:phase.stationary_units+=1
  if row.actions.is_empty():phase.inactive_units+=1
  if not e.alive(n):continue
  phase.unused_ap+=int(u.ap)
  if not u.command_ok:phase.command_cut+=1
  if not u.supply_ok:phase.supply_cut+=1
  if not u.command_ok and not u.supply_ok:phase.double_cut+=1
  if turn not in [6,9,12,15,18]:continue
  var info=legal_info(e,n)
  if info.can_act and int(info.reachable_empty)>0:phase.legally_mobile_at_end+=1
  if not info.legal_fire.is_empty() or not info.legal_assault.is_empty():phase.legally_attackable_at_end+=1
  var reason="acted"
  if row.actions.is_empty():
   if not info.can_act:reason="cannot_act"
   elif u.morale=="routed":reason="routed"
   elif not info.legal_assault.is_empty():reason="legal_assault_refused_by_policy"
   elif u.get("river_halt",false):reason="river_halt"
   elif int(info.reachable_empty)>0:reason="legal_destinations_not_selected"
   elif u.deployed:reason="deployed_no_selected_fire"
   else:reason="no_legal_destination_or_attack"
  result.units.append({"turn":turn,"id":id,"initial_cell":row.initial.cell,"final_cell":u.cell,"initial_ap":row.initial.ap,"unused_ap":u.ap,"spent_ap":row.ap_spent,"actions":row.actions,"command_ok":u.command_ok,"supply_ok":u.supply_ok,"isolation_turns":u.get("isolation_turns",0),"morale":u.morale,"ammo_level":u.ammo_level,"reason":reason,"legal":info,"crossings":row.crossings})
 result.phases.append(phase)
 print("ANALYSED T",turn," moved=",phase.moved_units," inactive=",phase.inactive_units," unused_ap=",float(phase.unused_ap)/4," crossings=",crossings.size())
func _initialize():
 profiles=JSON.parse_string(FileAccess.get_file_as_string("res://packs/1870/ai_profiles.json"))
 var report=existing_report();var raw=FileAccess.get_file_as_string("res://packs/1870/regimental_trial_v43.json");var e=Rules.new(JSON.parse_string(raw));e.new_game(0,"hard");e.state.seed=int(report.seed);e.state.ai_style=0
 var rows={};var counts={};var times=[];var crossings=[];var loss_start=[0,0];var own_started=false
 for k in range(report.actions.size()):
  var a=report.actions[k];var d=a.decision;var side=int(e.state.side);var turn=int(e.state.turn)
  check(side==int(a.side) and turn==int(a.turn),"replay boundary "+str(k))
  if side==1 and not own_started:
   rows=snapshots(e);counts={};times=[];crossings=[];loss_start=[e.losses(0),e.losses(1)];own_started=true
  if side==1:
   counts[d.kind]=int(counts.get(d.kind,0))+1;times.append(int(report.decision_ms[k]))
   if d.kind=="end":finish_phase(e,turn,rows,counts,times,crossings,loss_start);own_started=false
  var n=e.unit_index(str(d.get("unit","")));var before={}
  if side==1 and n>=0:before=e.state.units[n].duplicate(true)
  check(dispatch(e,d),"replayed command legal "+str(k))
  if failures>0:break
  if side==1 and n>=0:
   var row=rows[str(d.unit)];row.actions.append(d);row.ap_spent+=maxi(0,int(before.ap)-int(e.state.units[n].ap))
   if d.kind=="move":
    var actual=e.unit_cell(e.state.units[n]);var endpoint=-1
    for path_index in range(d.path.size()):
     if int(d.path[path_index])==actual:endpoint=path_index;break
    for j in range(1,endpoint+1):
     var key=e.river_key(int(d.path[j-1]),int(d.path[j]))
     if e.river_links.has(key):
      var crossing={"unit":d.unit,"from":d.path[j-1],"to":d.path[j],"ford":e.open_river(int(d.path[j-1]),int(d.path[j]))};crossings.append(crossing);row.crossings+=1
 if "--partial" not in OS.get_cmdline_user_args():check(e.state.finished and report.completed_turns==20,"full chronological replay finished")
 result.complete_campaign=e.state.finished
 var expected_hash=str(report.get("checkpoint_state_sha256",""))
 if "--partial" not in OS.get_cmdline_user_args():check(JSON.stringify(e.state).sha256_text()==expected_hash,"replay full final state hash identical to campaign checkpoint")
 result.final=metrics(e);result.captures=report.captures;result.seed=report.seed;result.pack_sha256=raw.sha256_text();result.baseline="Unmodified V43.1 policy; diagnostic copy only; legal actions replayed on original V43 engine"
 result.checks=checks;result.failures=failures
 var f=FileAccess.open("user://analysis.json",FileAccess.WRITE);f.store_string(JSON.stringify(result,"\t"));f.close()
 print("AUDIT REPLAY ",checks-failures,"/",checks);quit(1 if failures else 0)
