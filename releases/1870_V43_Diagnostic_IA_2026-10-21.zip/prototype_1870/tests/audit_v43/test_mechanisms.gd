extends "res://tests/v36/test_ai_active.gd"
const Original=preload("res://tests/audit_v43/original_ai.gd")
const Planning=preload("res://war_engine/ai/planning_engine.gd")
var output={"checks":0,"failures":0,"bridges":[],"ratio_cases":[],"parity":[]}
func _initialize():
 profiles=JSON.parse_string(FileAccess.get_file_as_string("res://packs/1870/ai_profiles.json"))
 var p=JSON.parse_string(FileAccess.get_file_as_string("res://packs/1870/regimental_trial_v43.json"))
 # Small, explicit legal mechanics fixtures on the original map. Not a reconstruction.
 var wanted=["pru_36","fr_1","pru_55","art_pr_Sandrart0"];var roster=[]
 for id in wanted:
  for u in p.units:
   if u.id==id:
    var c=u.duplicate(true);c.arrival_turn=1;roster.append(c);break
 p.units=roster;p.rules.support.enabled=false;p.rules.fog.enabled=false
 for turn in [3,4,12]:
  var e=Rules.new(p);e.new_game(0,"hard");e.state.turn=turn;e.state.side=1
  for n in range(e.state.units.size()):e.state.units[n].cell=[[13,11],[11,5],[10,13],[9,13]][n]
  var a=e.index(Vector2i(13,11));var b=e.index(Vector2i(14,11));var cases={"turn":turn,"open_river":e.open_river(a,b),"infantry_cost_quarters":e.step_cost(0,a,b),"cavalry_cost_quarters":e.step_cost(2,a,b),"artillery_cost_quarters":e.step_cost(3,a,b)}
  check(e.open_river(a,b)==(turn<4),"Woerth bridge opens at T4")
  check((e.step_cost(2,a,b)<0)==(turn<4) and (e.step_cost(3,a,b)<0)==(turn<4),"cavalry and artillery require bridge")
  var old_ap=int(e.state.units[0].ap);var moved=e.move(0,[a,b]);cases.move=moved;cases.remaining_ap=e.state.units[0].ap;cases.halt=e.state.units[0].river_halt
  check(moved in ["moved","capture","discovered"],"infantry river crossing legal")
  if turn<4:check(e.state.units[0].river_halt and int(e.state.units[0].ap)>0 and e.reach(0).costs.is_empty(),"ford leaves AP but prevents further movement")
  output.bridges.append(cases)
 # Find actual post-reaction ratios around the mismatch between exploitation 1.15 and assault 1.25.
 p.units=p.units.slice(0,2)
 for initial in [1000,1400,1800,2200,2600,2900]:
  var e=Rules.new(p);e.new_game(0,"hard");e.state.side=1;e.state.turn=12;e.state.ai_style=0;e.state.seed=430012
  e.state.units[0].cell=[11,6];e.state.units[1].cell=[11,5];e.state.units[0].initial_strength=initial;e.state.units[0].strength=initial
  e.refresh_intel();var ai=bot();var baseline=Original.new();baseline.profiles=profiles
  var view=e.observation(1,[1]);var snapshot=view.duplicate(true);var a=ai.choose(view);var b=baseline.choose(view)
  check(a==b and view==snapshot,"instrumentation decision parity in ratio fixture")
  var planning=Planning.new(view.pack,view.state);var exploitation=ai.exploitation_value(planning,0,planning.index(Vector2i(11,5)))
  output.ratio_cases.append({"exploitation_value":exploitation,"prussian_strength":initial,"french_strength":e.state.units[1].strength,"terrain":e.pack.map.tiles[e.unit_cell(e.state.units[1])],"decision":a,"diagnostics":ai.diagnostics})
 # Original full roster, five synthetic clock offsets: same initial deployment, no invented history.
 var raw=JSON.parse_string(FileAccess.get_file_as_string("res://packs/1870/regimental_trial_v43.json"))
 for turn in [6,9,12,15,18]:
  var e=Rules.new(raw);e.new_game(0,"hard");e.state.side=1;e.state.turn=turn;e.state.seed=430012;e.state.ai_style=0
  e.arrive_reinforcements();e.refresh_support();e.refresh_intel()
  var ai=bot();var baseline=Original.new();baseline.profiles=profiles
  var view=e.observation(1);var snapshot=view.duplicate(true);var started=Time.get_ticks_msec();var a=baseline.choose(view);var elapsed=Time.get_ticks_msec()-started;var b=ai.choose(view)
  check(a==b and view==snapshot,"full-roster instrumentation parity T"+str(turn))
  output.parity.append({"turn":turn,"decision":a,"baseline_ms":elapsed,"urgency":ai.urgency,"trace":ai.diagnostics})
 output.checks=checks;output.failures=failures
 var f=FileAccess.open("user://mechanisms.json",FileAccess.WRITE);f.store_string(JSON.stringify(output,"\t"));f.close()
 print("AUDIT MECHANISMS ",checks-failures,"/",checks);quit(1 if failures else 0)
