extends "res://tests/test_ai_compat0833.gd"
const Original=preload("res://tests/audit_v43/original_ai.gd")
func _initialize():
 profiles=JSON.parse_string(FileAccess.get_file_as_string("res://packs/1870/ai_profiles.json"))
 var directory=OS.get_cmdline_user_args()[0];var rows=[];var entries=DirAccess.get_files_at(directory);entries.sort()
 var p=JSON.parse_string(FileAccess.get_file_as_string("res://packs/1870/regimental_trial_v43.json"))
 for name in entries:
  if not name.begins_with("trace_T"):continue
  if OS.get_cmdline_user_args().size()>1 and not name.substr(7,2) in OS.get_cmdline_user_args()[1].trim_prefix("--only=").split(","):continue
  var trace=JSON.parse_string(FileAccess.get_file_as_string(directory.path_join(name)));var e=Rules.new(p);e.state=trace.state;e.normalize()
  var view=e.observation(1);var prior=view.duplicate(true);var original=Original.new();original.profiles=profiles;var probe=bot()
  var started=Time.get_ticks_msec();var a=original.choose(view);var baseline_ms=Time.get_ticks_msec()-started
  started=Time.get_ticks_msec();var b=probe.choose(view);var instrumented_ms=Time.get_ticks_msec()-started
  check(a==b and JSON.parse_string(JSON.stringify(a))==trace.decision and prior==view,"original/instrumented/recorded decision parity "+name)
  rows.append({"trace":name,"original":a,"instrumented":b,"recorded":trace.decision,"baseline_ms":baseline_ms,"instrumented_ms":instrumented_ms,"units":probe.diagnostics,"urgency":probe.urgency})
 var f=FileAccess.open("user://trace_comparison.json",FileAccess.WRITE);f.store_string(JSON.stringify({"checks":checks,"failures":failures,"rows":rows},"\t"));f.close()
 print("TRACE PARITY ",checks-failures,"/",checks);quit(1 if failures else 0)
