extends "res://tests/audit_v43/analyse_campaign.gd"
func _initialize():
 profiles=JSON.parse_string(FileAccess.get_file_as_string("res://packs/1870/ai_profiles.json"))
 var report=existing_report();var directory=OS.get_cmdline_user_args()[1];var entries=DirAccess.get_files_at(directory);entries.sort()
 var p=JSON.parse_string(FileAccess.get_file_as_string("res://packs/1870/regimental_trial_v43.json"))
 var only=OS.get_cmdline_user_args()[2].trim_prefix("--only=").split(",") if OS.get_cmdline_user_args().size()>2 else PackedStringArray()
 for turn in [6,9,12,15,18]:
  if not only.is_empty() and not str(turn) in only:continue
  var files=[]
  for name in entries:
   if name.begins_with("trace_T%02d_"%turn):files.append(name)
  if files.size()!=2:continue
  var first=JSON.parse_string(FileAccess.get_file_as_string(directory.path_join(files[0])));var last=JSON.parse_string(FileAccess.get_file_as_string(directory.path_join(files[1])))
  if last.decision.kind!="end":continue
  var begin_index=int(files[0].get_basename().get_slice("_A",1));var end_index=int(files[1].get_basename().get_slice("_A",1))
  var e=Rules.new(p);e.state=first.state;e.normalize();var rows=snapshots(e);var counts={};var times=[];var crossings=[];var loss_start=[e.losses(0),e.losses(1)];var bombarded={};var prepared_assaults=0
  for id in rows:
   rows[id].move_history=[];rows[id].seen_positions={str(rows[id].initial.cell):true};rows[id].initial_goal=first.units.get(id,{}).get("goal",[])
  for k in range(begin_index,end_index):
   var a=report.actions[k];var d=a.decision;var n=e.unit_index(str(d.get("unit","")));var before={}
   if n>=0:before=e.state.units[n].duplicate(true)
   check(int(a.side)==1 and int(a.turn)==turn,"window command belongs to Prussian phase")
   check(dispatch(e,d),"window command legal "+str(k))
   counts[d.kind]=int(counts.get(d.kind,0))+1;times.append(int(report.decision_ms[k]))
   if d.kind=="fire":
    var category="artillery_fire" if e.artillery(n) else "hq_fire" if e.headquarters(n) else "infantry_fire"
    counts[category]=int(counts.get(category,0))+1
    if e.artillery(n):bombarded[str(d.target)]=true
   if d.kind=="assault" and bombarded.has(str(d.target)):prepared_assaults+=1
   if n>=0:
    var row=rows[str(d.unit)];row.actions.append(d);row.ap_spent+=maxi(0,int(before.ap)-int(e.state.units[n].ap))
    if d.kind=="move":
     var position=e.state.units[n].cell.duplicate();var repeated=row.seen_positions.has(str(position));row.seen_positions[str(position)]=true
     row.move_history.append({"from":before.cell,"to":position,"ap_spent":maxi(0,int(before.ap)-int(e.state.units[n].ap)),"repeated_position":repeated})
     var actual=e.unit_cell(e.state.units[n]);var endpoint=-1
     for path_index in range(d.path.size()):
      if int(d.path[path_index])==actual:endpoint=path_index;break
     check(endpoint>0,"actual endpoint belongs to successful movement prefix")
     for j in range(1,endpoint+1):
      var key=e.river_key(int(d.path[j-1]),int(d.path[j]))
      if e.river_links.has(key):
       var crossing={"unit":d.unit,"from":d.path[j-1],"to":d.path[j],"ford":e.open_river(int(d.path[j-1]),int(d.path[j]))};crossings.append(crossing);row.crossings+=1
  counts.assaults_after_artillery=prepared_assaults
  counts.end=1;times.append(int(report.decision_ms[end_index]))
  check(JSON.parse_string(JSON.stringify(e.state))==last.state,"full phase replay state exactly matches recorded end T"+str(turn))
  finish_phase(e,turn,rows,counts,times,crossings,loss_start)
  for row in result.units:
   if int(row.turn)!=turn:continue
   row.move_history=rows[row.id].move_history;row.initial_goal=rows[row.id].initial_goal
   var trace=last.units.get(row.id,first.units.get(row.id,{}));row.decision_trace=trace
   if not row.actions.is_empty():continue
   if not str(trace.get("hold","")).is_empty():row.reason=str(trace.hold)
   elif row.legal.can_act and int(row.legal.reachable_empty)>0 and float(trace.get("best_move_score",1e20))<=3:row.reason="all_movement_scores_below_minimum"
 result.seed=report.seed;result.complete_campaign=report.completed_turns==20;result.final=report.get("final",{});result.captures=report.captures
 result.checks=checks;result.failures=failures
 var f=FileAccess.open("user://windows_analysis.json",FileAccess.WRITE);f.store_string(JSON.stringify(result,"\t"));f.close()
 print("AUDIT WINDOWS ",checks-failures,"/",checks);quit(1 if failures else 0)
