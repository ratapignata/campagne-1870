extends "res://tests/test_ai_compat0833.gd"
const Original=preload("res://tests/audit_v43/original_ai.gd")
const Planning=preload("res://war_engine/ai/planning_engine.gd")
func _initialize():
 profiles=JSON.parse_string(FileAccess.get_file_as_string("res://packs/1870/ai_profiles.json"))
 var p=JSON.parse_string(FileAccess.get_file_as_string("res://packs/1870/regimental_trial_v43.json"));var units=[]
 for id in ["pru_36","fr_1","pru_37"]:
  for u in p.units:
   if u.id==id:
    var c=u.duplicate(true);c.arrival_turn=1;units.append(c);break
 p.units=units;p.rules.support.enabled=false;p.rules.fog.enabled=false
 var e=Rules.new(p);e.new_game(0,"hard");e.state.turn=12;e.state.side=1;e.state.seed=430012;e.state.ai_style=0
 e.state.units[0].cell=[12,5];e.state.units[1].cell=[11,5];e.state.units[2].cell=[11,6]
 check(e.fire_status(2,1)=="ok","legal preparatory French-visible infantry exchange")
 var exchange=e.fire(2,1)
 check(exchange.status=="ok" and exchange.event.reaction,"defender reaction really occurred")
 check(int(e.state.units[1].reactions)==0 and e.reaction_status(1,0)=="spent","actual reaction exhausted for this phase")
 var found={};var ai=bot()
 for strength in range(500,2901,10):
  e.state.units[0].strength=strength;e.state.units[0].initial_strength=strength
  var view=e.observation(1,[1]);var plan=Planning.new(view.pack,view.state);var n=plan.unit_index("pru_36");var j=plan.unit_index("fr_1")
  var actual=e.attack_power_against(0,1)/maxf(1,e.defence_power_against(1,0))
  var response=ai.mean_loss(plan,j,n,float(plan.pack.rules.combat.reaction_factor))
  var predicted=plan.attack_power_against(n,j)*plan.melee_strength(n,j,maxf(0.0,float(strength)-response))/maxf(1,plan.melee_strength(n,j,float(strength)))/maxf(1,plan.defence_power_against(j,n))
  if actual>=1.25 and predicted<1.25:
   var baseline=Original.new();baseline.profiles=profiles;var decision=ai.choose(view)
   check(decision==baseline.choose(view),"original and instrumented decisions identical")
   check(int(plan.state.units[j].reactions)==1 and plan.reaction_status(j,n)=="ok","observation restores estimated enemy reaction")
   found={"attacker_strength":strength,"defender_strength":e.state.units[1].strength,"actual_ratio_no_reaction":actual,"estimated_ratio_with_phantom_reaction":predicted,"estimated_response":response,"actual_reactions":e.state.units[1].reactions,"observed_reactions":plan.state.units[j].reactions,"observed_own_exchange":exchange.event,"decision":decision,"trace":ai.diagnostics,"hypotheses":"3-unit fixture, original map, support/fog disabled, enemy explicitly provided; attacker strength searched to isolate estimator threshold effect. No new combat rule."};break
 check(not found.is_empty(),"reproducible near-threshold effect found after a real witnessed reaction")
 var f=FileAccess.open("user://observed_reaction.json",FileAccess.WRITE);f.store_string(JSON.stringify({"checks":checks,"failures":failures,"case":found},"\t"));f.close()
 print("OBSERVED REACTION AUDIT ",checks-failures,"/",checks);quit(1 if failures else 0)
