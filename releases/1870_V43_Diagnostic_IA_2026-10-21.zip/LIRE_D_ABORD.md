# Diagnostic IA V43 — 21 octobre 2026

Lire Rapport_IA_V43/AUDIT_IA_V43.md, puis REPRODUIRE.md. prototype_1870 est une copie de test instrumentée de V43.1, avec les mêmes décisions IA et règles ; ce n’est pas la livraison Android V43.2.

L’APK et les sources de production V43.2 sont disponibles dans le dépôt ratapignata/campagne-1870, dossier releases. Ils ajoutent uniquement l’export JSON ; aucune correction du comportement IA n’est appliquée.

20 tours des 95 unités réellement terminés ; aucun essai Android physique. La partie personnelle du joueur n’est pas reproduite faute de sauvegarde.
